<div class="row-fluid" id="footer"><br/>
		<center><a href="#"> &copy Pandian, Krishnan & Gans </a></center><br/>
</div>