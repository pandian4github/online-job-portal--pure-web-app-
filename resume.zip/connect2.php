<?php
mysqli_connect()
?>