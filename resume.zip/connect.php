<?php
	$dbc=mysqli_connect('localhost','resume','resume','resume') or die("Couldn't connect to the database");
?>